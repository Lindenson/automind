"""Graph state (data-model §6). The case file itself lives in the DB (versioned); state holds only
workflow data and compact references. One persistent thread per chat, so per-turn keys are reset
by `load_case` at the start of every turn."""

from __future__ import annotations

from typing import Annotated, Any, TypedDict

from automind.chat.application.services.report.blocks.notice import Notice
from automind.chat.application.services.research.contracts import JobResult, JobState, LimitHit, PlanState
from automind.chat.domain.decision import RequestKind

RESET = "__reset__"


def results(old: list[Any] | None, new: list[Any] | None) -> list[Any]:
    """Reducer for parallel research workers: append, or reset when a list starts with RESET."""
    if new and new[0] == RESET:
        return list(new[1:])
    return [*(old or []), *(new or [])]


class DecisionState(TypedDict, total=False):
    """The policy's Action as stored in the graph state (plain data: the checkpoint never holds a class)."""

    kind: str  # chat.domain.decision.ActionKind
    questions: list[str]
    cars: list[str]
    nothing_new: bool
    profile: bool
    over_cap: bool
    reason: str


class TurnState(TypedDict, total=False):
    chat_id: str
    turn_id: str
    user_text: str
    language: str
    request_kind: RequestKind | None
    interpretation: dict[str, Any]
    case_version: int
    assessments: dict[str, dict[str, Any]]  # car key -> {state, candidates, generations}
    decision: DecisionState  # the policy's Action (model_dump)
    action: str  # final action kind of the turn (recorded on the turn)
    cost_estimate: float | None
    research_plan: PlanState
    jobs: list[JobState]
    round: int
    cost_approved: bool
    research_declined: bool
    research_done: bool
    confirm_payload: dict[str, Any] | None
    resume: dict[str, Any] | None
    research_results: Annotated[list[JobResult], results]
    notices: list[Notice]
    reply_text: str
    blocks: list[dict[str, Any]]
    fingerprint: str | None
    done: bool
    route: str | None
    case_changed: bool
    persona_changed: bool
    limit_hit: LimitHit | None  # research paused at a limit (asks the user, never cancels)
    limit_extensions: int  # how many times the user said "continue" in this turn
    feasibility: dict[str, Any] | None  # {results, fingerprint} from application.feasibility (spec 003 US3)
    preset: dict[str, Any] | None  # a request from a button (no interpretation): {kind, focus_cars, areas, language}
    not_understood: list[str]  # car keys whose question the last message did not answer (spec 004 FR-031)
    picked: bool  # the message was one of the offered options, applied by code (spec 007 F)
    hops: int  # policy passes in this turn (spec 007 FR-027)


PER_TURN_RESET: dict[str, Any] = {
    "language": "en",
    "request_kind": None,
    "assessments": {},
    "decision": {},
    "action": None,
    "cost_estimate": None,
    "research_plan": {},
    "jobs": [],
    "round": 0,
    "cost_approved": False,
    "research_declined": False,
    "research_done": False,
    "limit_hit": None,
    "limit_extensions": 0,
    "feasibility": None,
    "not_understood": [],
    "picked": False,
    "hops": 0,
    "confirm_payload": None,
    "resume": None,
    "research_results": [RESET],
    "notices": [],
    "reply_text": "",
    "blocks": [],
    "fingerprint": None,
    "done": False,
    "route": None,
    "case_changed": True,
    "persona_changed": False,
}
